import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/core/services/api.service';
import { UserService } from 'src/app/core/services/user.service';
import {User} from '../../core/models/user.model';
@Component({
  selector: 'app-who-am-i',
  templateUrl: './who-am-i.component.html',
  styleUrls: ['./who-am-i.component.css']
})
export class WhoAmIComponent implements OnInit {
  email : string;
  user : User = {};
  constructor(private apiService : ApiService,private userService : UserService) { }

  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
    this.userService.GetUser(this.email)
    .subscribe(data=>{
      if(data){
        this.user = data;
      }
    })
  }

}
