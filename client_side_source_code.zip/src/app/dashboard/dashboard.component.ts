import { Component, OnInit } from '@angular/core';
import {MatDialog,MatDialogRef,MatDialogModule } from '@angular/material/dialog';
import { ComposeTweetComponent } from './compose-tweet/compose-tweet.component';
import { Tweet } from '../core/models/tweet.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  	tweet : Tweet;
  constructor(public dialog : MatDialog,private router : Router) { }

  ngOnInit() {
    
  }
  newTweet(){
    console.log('sdlvkd');
    const dialogRef = this.dialog.open(ComposeTweetComponent,{
      width : '800 px',
      height : '40%',
      data: {tweet : this.tweet}
    });
    // dialogRef.updatePosition({ bottom : '100%', left: '20%' });
    dialogRef.afterClosed().subscribe(result=> {
      console.log('tdhvjs');
      window.location.reload();
    });
  }
  WhoAmI(){
    this.router.navigate(['/WhoAmI']);
  }

}
