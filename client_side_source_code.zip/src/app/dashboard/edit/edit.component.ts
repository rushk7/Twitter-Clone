import { Component, OnInit , Inject } from '@angular/core';
import { FormGroup , FormBuilder,Validators} from '@angular/forms';
import { Tweet } from 'src/app/core/models/tweet.model';
import {MatDialogRef , MAT_DIALOG_DATA} from '@angular/material/dialog';
import { TweetService } from 'src/app/core/services/tweet.service';
import { ApiService } from 'src/app/core/services/api.service';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  tweetForm : FormGroup;
  tweet : Tweet = {};
  email : string;
  constructor(private fb : FormBuilder,public dialogRef: MatDialogRef<EditComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private tweetService : TweetService,private apiService : ApiService) {
    this.tweetForm = fb.group({
      content : ['',Validators.required]
    });
   }


  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
  }
  editTweet(){
    this.tweet.content = this.tweetForm.get('content').value;
    this.tweet.email = this.email;
    console.log('d,nvdkb');
    this.tweetService.EditTweet(this.tweet)
    .subscribe(data =>{
      if(data){
        console.log('this happejned');
        this.dialogRef.close();
        window.location.reload();
      }
      else{
        console.log('slvmmnksnv');
      }
    });
    
  }

}
