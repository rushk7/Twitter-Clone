import { Component, OnInit } from '@angular/core';
import { Tweet } from 'src/app/core/models/tweet.model';
import { TweetService } from 'src/app/core/services/tweet.service';
import { ApiService } from 'src/app/core/services/api.service';

@Component({
  selector: 'app-tweet-list',
  templateUrl: './tweet-list.component.html',
  styleUrls: ['./tweet-list.component.css']
})
export class TweetListComponent implements OnInit {
  tweetList : Tweet[] = [];
  email : string;
  constructor(private tweetService : TweetService,private apiService : ApiService) {
  }

  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
    this.tweetService.GetTweetsForUser(this.email)
    .subscribe(data =>{
      if(data){
        this.tweetList = data;
      }
    });
  }

}
