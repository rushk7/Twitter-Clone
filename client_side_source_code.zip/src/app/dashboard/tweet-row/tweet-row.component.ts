import { Component, OnInit, Input } from '@angular/core';
import { Tweet } from 'src/app/core/models/tweet.model';
import { User } from 'src/app/core/models/user.model';
import {MatDialog,MatDialogRef,MatDialogModule } from '@angular/material/dialog';
import {EditComponent} from '../edit/edit.component';
import { TweetService } from 'src/app/core/services/tweet.service';
import { ApiService } from 'src/app/core/services/api.service';
import { Router } from '@angular/router';
import {LikeService} from '../../core/services/like.service'
import { Person } from 'src/app/core/models/person.model';
import { PersonService } from 'src/app/core/services/person.service';
3

@Component({
  selector: 'app-tweet-row',
  templateUrl: './tweet-row.component.html',
  styleUrls: ['./tweet-row.component.css']
})
export class TweetRowComponent implements OnInit {
  @Input() tweet : Tweet;
  person : Person = {};
  email : string = "";
  likeNumber : number;
  disLikeNumber : number;
  userTweet : boolean;
  constructor(private dialog : MatDialog,private tweetService : TweetService,private apiSerice : ApiService,private router : Router,private likeService : LikeService,private personService : PersonService) {
    console.log(this.tweet);
   }

  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
    console.log(this.email);
    if(this.tweet.email == this.email)
      this.userTweet = true;
    else  
      this.userTweet = false;
      console.log(this.userTweet);
    // Gets the person to display person's name and profile Pic
    this.personService.GetPerson(this.tweet.email)
    .subscribe(data =>{
      if(data){
        this.person = data;
        console.log('lmmdfvld');
        console.log(this.person);
      }
     
    });
    console.log('this happened');
    this.likeService.LikeNumber(this.tweet.id)
    .subscribe(data =>{
      this.likeNumber = data;

    });
    this.likeService.DisLikeNumber(this.tweet.id)
    .subscribe(data=>{
      this.disLikeNumber = data;
    });
    
  
  }
  Edit(){
    console.log('sdlvkd');
    const dialogRef = this.dialog.open(EditComponent,{
      width : '500 px',
      height : '40%',
      data: {tweet : this.tweet}
    });
    // dialogRef.updatePosition({ bottom : '100%', left: '20%' });
    dialogRef.afterClosed().subscribe(result=> {
      console.log('tdhvjs');
      this.router.navigate(['/dashboard'])
    });
  }
  Delete(){
    console.log('this is happending');
    this.tweetService.DeleteTweet(this.tweet.id)
    .subscribe(data =>{
      if(data){
        console.log('thisshit isskjvnkdv');
        window.location.reload();
      }
      else{
        console.log('vkjbdfv');
      }
    })
   
  } 
  Like(){
   
    this.likeService.LikeValue(this.tweet.id,this.email)
    .subscribe(data =>{
      if(data == 0 || data == -1){
        this.likeService.Like(this.tweet.id,this.email)
        .subscribe(data=>{
          console.log('like happend');
          console.log(data);
          this.likeService.LikeNumber(this.tweet.id)
          .subscribe(data =>{
            this.likeNumber = data;
            console.log('1',data);
          });
          this.likeService.DisLikeNumber(this.tweet.id)
          .subscribe(data=>{
            this.disLikeNumber = data;
            console.log('2',data);
          });
        });
     
       
      }
    
      });
     
  
  }
  DisLike(){
    
    //We have to make logic for this shit
    this.likeService.LikeValue(this.tweet.id,this.email)
    .subscribe(data =>{
      console.log(data);
      if(data == 0 || data == 1){
        this.likeService.DisLike(this.tweet.id,this.email)
        .subscribe(data =>{
          console.log('dislike happened');
          console.log(data);
          this.likeService.LikeNumber(this.tweet.id)
          .subscribe(data =>{
            this.likeNumber = data;
            console.log('1',data);
          });
          this.likeService.DisLikeNumber(this.tweet.id)
          .subscribe(data=>{
            this.disLikeNumber = data;
            console.log('2',data);
          });
        });

      }
    
    });
  }

}
