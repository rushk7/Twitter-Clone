import { Component, OnInit } from '@angular/core';
import {Person} from '../../core/models/person.model';
import { PersonComponent } from '../person/person.component';
import { PersonService } from 'src/app/core/services/person.service';
@Component({
  selector: 'app-followers',
  templateUrl: './followers.component.html',
  styleUrls: ['./followers.component.css']
})
export class FollowersComponent implements OnInit {
  followers : Person[] = [] ;
  email : string;
  constructor(private personService : PersonService) {

   }

  ngOnInit() {
    console.log(this.followers);
    this.email = localStorage.getItem('currentuser');
    this.personService.GetFollowers(this.email)
    .subscribe(data=> {
      if(data){
        this.followers = data;
      }
    })
  }

}
