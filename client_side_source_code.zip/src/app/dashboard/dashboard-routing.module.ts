import { ModuleWithProviders,NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';

import {FollowersComponent} from './followers/followers.component';
import {FollowingComponent} from './followings/following.component';
import {SearchComponent} from './search/search.component';
import {AnalyticsComponent} from './analytics/analytics.component';
import {WhoAmIComponent} from './who-am-i/who-am-i.component';
const Dashboardroutes: Routes = [
  {
    path:'dashboard',
    component: DashboardComponent,
    
  },
  
  {
    path:'following',
    component: FollowingComponent,
  },
  {
    path:'followers',
    component: FollowersComponent,
  },
  {
    path:'search',
    component: SearchComponent,
  },
  {
    path:'analytics',
    component: AnalyticsComponent,
  },
  {
    path: 'WhoAmI',
    component : WhoAmIComponent,
  }

];

@NgModule({
  imports: [RouterModule.forChild(Dashboardroutes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
