import { Component, OnInit , Inject } from '@angular/core';
import { FormGroup , FormBuilder,Validators} from '@angular/forms';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material';
import {MatDialogRef} from '@angular/material/dialog';
import { Tweet } from 'src/app/core/models/tweet.model';
import { TweetService } from 'src/app/core/services/tweet.service';
@Component({
  selector: 'app-compose-tweet',
  templateUrl: './compose-tweet.component.html',
  styleUrls: ['./compose-tweet.component.css']
})
export class ComposeTweetComponent implements OnInit {
  tweetForm : FormGroup;
  tweet : Tweet = {email : '',content : ''};
  email : string = "";
  constructor(private fb : FormBuilder,public dialogRef: MatDialogRef<ComposeTweetComponent>,@Inject(MAT_DIALOG_DATA) public data: any,private tweetService : TweetService) {
    this.tweetForm = fb.group({
      content : ['',Validators.required]
    });
   }


  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
    console.log(this.email);
  }
  PostTweet(){
    console.log('this is shit');
    this.tweet.content = this.tweetForm.get('content').value;
    this.tweet.email = this.email;
    console.log(this.tweet);
    this.tweetService.AddTweet(this.tweet)
    .subscribe(data => {
      if(data)
        this.dialogRef.close();
    });
    
  }

}
