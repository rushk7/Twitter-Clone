import { Component, OnInit , Input } from '@angular/core';
import { Person } from 'src/app/core/models/person.model';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { PersonService } from 'src/app/core/services/person.service';
import { ThrowStmt } from '@angular/compiler';


@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {
  @Input() p: Person;
  @Input() follow : Boolean;
  @Input() unfollow : Boolean;
  @Input() followers : Boolean;
  constructor(private router : Router,private apiService : ApiService,private personService : PersonService) { }
  email : string;
  ngOnInit() {
   
    this.email = localStorage.getItem('currentuser');
    if(this.p.email == this.email){
      this.follow = false;
      this.unfollow = false;
    }
    if(this.followers == true){
      this.personService.DoIFollow(this.email,this.p.email)
      .subscribe(data =>{
        if(data){
          this.follow = false;
          this.unfollow = true;
        }
        else{
          this.unfollow = false;
          this.follow = true;
        }
      })
    }
  }
  Follow(){
    console.log('this happened');
    this.personService.Follow(this.p,this.email)
    .subscribe(data=>{
      console.log(data);
    });
    if(this.followers == true){
      this.personService.DoIFollow(this.email,this.p.email)
      .subscribe(data =>{
        if(data){
          this.follow = false;
          this.unfollow = true;
        }
        else{
          this.unfollow = false;
          this.follow = true;
        }
      })
    }
    window.location.reload();
    
  }
  UnFollow(){
    this.personService.UnFollow(this.p,this.email)
    .subscribe(data =>{
      console.log(data);
    });
    if(this.followers == true){
      this.personService.DoIFollow(this.email,this.p.email)
      .subscribe(data =>{
        if(data){
          this.follow = false;
          this.unfollow = true;
        }
        else{
          this.unfollow = false;
          this.follow = true;
        }
      })
    }
    window.location.reload();
  }
}
