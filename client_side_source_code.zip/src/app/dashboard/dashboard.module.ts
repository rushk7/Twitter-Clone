import {  NgModule} from '@angular/core';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import { SharedModule } from '../SHARED/shared.module';

import { FollowersComponent } from './followers/followers.component';
import { FollowingComponent } from './followings/following.component';
import { SearchComponent } from './search/search.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { TweetListComponent } from './tweet-list/tweet-list.component';

import { TweetRowComponent } from './tweet-row/tweet-row.component';

import { PersonComponent } from './person/person.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { ComposeTweetComponent } from './compose-tweet/compose-tweet.component';
import {MatDialog,MatDialogRef, MatDialogModule} from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EditComponent } from './edit/edit.component';

import { UserCredentialService } from '../core/services/usercredential.service';
import { UserService } from '../core/services/user.service';
import { PersonService } from '../core/services/person.service';
import { AnalyticsService } from '../core/services/analytics.service';
import { TweetService } from '../core/services/tweet.service';
import { ApiService } from '../core/services/api.service';
import { JwtService } from '../core/services/jwt.service';
import {MatTabsModule} from '@angular/material/tabs';
import { WhoAmIComponent } from './who-am-i/who-am-i.component';

@NgModule({
  imports: [
    DashboardRoutingModule,
    FormsModule,
    BrowserModule,
 
    ReactiveFormsModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MatTabsModule

  ],
  declarations: [
    DashboardComponent,

    FollowersComponent,
    FollowingComponent,
    SearchComponent,
    AnalyticsComponent,
    TweetListComponent,
   
    TweetRowComponent,
  
   
    PersonComponent,
  
   
    NavBarComponent,
  
   
    ComposeTweetComponent,
  
   
    EditComponent,
  
   
    WhoAmIComponent,
  
   
  
    
  ],
  exports : [
    DashboardComponent
  ],
  entryComponents: [
    ComposeTweetComponent,EditComponent
],
providers: [
  PersonService,AnalyticsService,TweetService,ApiService,JwtService
 ]
  
})
export class DashboardModule {}
