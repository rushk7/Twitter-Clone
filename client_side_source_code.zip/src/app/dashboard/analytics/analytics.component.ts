import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/core/services/api.service';
import { AnalyticsService } from 'src/app/core/services/analytics.service';
import { Analytics } from 'src/app/core/models/analytics.model';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.css']
})
export class AnalyticsComponent implements OnInit {
  analytics : Analytics = {}
  constructor(private router : Router,private apiService : ApiService,private analyticsService : AnalyticsService) { }

  ngOnInit() {
    this.analyticsService.GetAnalyticsToday()
      .subscribe(data=>{
        if(data){
          this.analytics = data;
          console.log(data);
        }});

  }


}
