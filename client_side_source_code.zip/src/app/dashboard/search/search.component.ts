import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {Person} from '../../core/models/person.model';
import {Tweet} from '../../core/models/tweet.model';
import { PersonService } from 'src/app/core/services/person.service';
import { TweetService } from 'src/app/core/services/tweet.service';
import {TemporaryObject} from '../../core/models/temporaryObject.model';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})

export class SearchComponent implements OnInit {
  temporaryList : TemporaryObject[] = [];
  query = new FormControl('');
  constructor(private personService : PersonService,private tweetService : TweetService) { }
  people : Person[] = [];
  following : Boolean[] = [];
  posts : Tweet[] = [];
  email : string;
  follow_hide : Boolean;
  unfollow_hide : Boolean;
  ngOnInit() {
    this.email = localStorage.getItem('currentuser');
   
  }

  submit(){
  
    let searchString = this.query.value;
    console.log(searchString);
   
    this.temporaryList = []
    this.personService.SearchPeople(searchString,this.email)
    .subscribe(data =>{
      if(data){
        // console.log(data);
        // console.log(data["m_Item1"]);
        this.people = data["m_Item1"];
        this.following = data["m_Item2"];
        //.log(this.people);
        for(var i = 0;i<this.people.length;i++){
          let Temp :TemporaryObject = {person : this.people[i],following:this.following[i]}
          this.temporaryList.push(Temp);
        }
        
      }
      else{
        console.log('this is not happenning');
      }
    }
      );
      
      
    this.posts = [];
    this.tweetService.SearchTweetsForUser(searchString)
    .subscribe(data =>{
      if(data){
        this.posts = data;
        console.log(data);
      }
      else{
        console.log('this is null');
      }
    });

  }
}
