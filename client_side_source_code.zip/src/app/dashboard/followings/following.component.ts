import { Component, OnInit } from '@angular/core';
import {Person} from '../../core/models/person.model';
import { PersonService } from 'src/app/core/services/person.service';
@Component({
  selector: 'app-following',
  templateUrl: './following.component.html',
  styleUrls: ['./following.component.css']
})
export class FollowingComponent implements OnInit {

  followings : Person[] = [] ;
  email : string;

  constructor(private personService : PersonService) {
 
   }

  ngOnInit() {
    console.log(this.followings);
    console.log(this.followings);
    this.email = localStorage.getItem('currentuser');
    this.personService.GetFollowing(this.email)
    .subscribe(data=> {
      if(data){
        this.followings = data;
      }
    })
  }

}
