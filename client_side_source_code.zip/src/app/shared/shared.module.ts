import { ModuleWithProviders, NgModule } from '@angular/core';
import {HeaderComponent} from './header/header.component';
import {FooterComponent} from './footer/footer.component';


import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
@NgModule({

  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedRoutingModule,
    
  ],
  declarations: [
  
    HeaderComponent,
    FooterComponent,
 

  ],
  providers: [
    
  ],
  exports : [
 
    HeaderComponent,
    FooterComponent,
   
  ]
})
export class SharedModule {}
