import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { JwtService } from './jwt.service';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import {Person} from '../models/person.model';
@Injectable()
export class ApiService {
  constructor(
    private http: HttpClient,
    private jwtService: JwtService
  ) {}
  headers={
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin' : "*",
    })
};
  private formatErrors(error: any) {
    return  throwError(error.error);
  }

  get(path: string): Observable<any> {
    return this.http.get(environment.api_url + path)
      .pipe(catchError(this.formatErrors));
  }
  get1(path : string , email : string) : Observable<any>{
    let params = new HttpParams().set('email',email);
    return this.http.get(environment.api_url + path,{params : params})
      .pipe(catchError(this.formatErrors));
  }
  get2(path : string,query:string,email:string):Observable<any>{
    let params = new HttpParams().set('query',query)
                                  .set('email',email);
    return this.http.get(environment.api_url + path,{params : params})
      .pipe(catchError(this.formatErrors));                            

  }
  get3(path : string,email:string,tweetId : number) : Observable<any>{
    let params = new HttpParams().set('email',email)
                                  .set('tweetId',tweetId.toString());
    return this.http.get(environment.api_url + path,{params : params})
  .pipe(catchError(this.formatErrors));
  }

  get4(path:string,query:string) : Observable<any>{
    let params = new HttpParams().set('query',query);
    return this.http.get(environment.api_url + path,{params : params})
    .pipe(catchError(this.formatErrors));  
  }
  get5(path:string,email:string,email1:string):Observable<any>{
    let params = new HttpParams().set('email',email)
                                  .set('email1',email1);
    return this.http.get(environment.api_url + path,{params : params})
    .pipe(catchError(this.formatErrors));                               
  }
  
 
  put(path: string, body: Object = {}): Observable<any> {
    return this.http.put(environment.api_url + path,
      JSON.stringify(body),this.headers
    ).pipe(catchError(this.formatErrors));
  }

  post(path: string, body: Object = {}): Observable<any> {
    return this.http.post(environment.api_url + path,
      JSON.stringify(body),this.headers
    ).pipe(catchError(this.formatErrors));
  }
  post1(path:string,person : Person,email : string):Observable<any>{
    let body = {'person' : person,'email' : email};
    return this.http.post(environment.api_url + path,
      JSON.stringify(body),this.headers
    ).pipe(catchError(this.formatErrors));
  }
  post2(path:string,email :string,tweetId : number):Observable<any>{
    let body = {'email' : email,'tweetId' : tweetId}
     return this.http.post(environment.api_url + path,JSON.stringify(body),this.headers)  
      .pipe(catchError(this.formatErrors));
  }
  

  delete(path : string): Observable<any> {
    return this.http.delete(
      environment.api_url + path
    ).pipe(catchError(this.formatErrors));
  }

}
