import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
import { UserCredential } from '../models/usercredential.model';

@Injectable({
  providedIn: 'root'
})
export class LikeService {
    constructor(private apiService : ApiService) { }
    Like(tweetId : number, email : string) : Observable<any>{
        return this.apiService.post2('Like',email,tweetId);
    }
    DisLike(tweetId : number,email : string):Observable<any>{
        return this.apiService.post2('DisLike',email,tweetId);
    }
    LikeValue(tweetId : number,email : string):Observable<number>{

        return this.apiService.get3('LikeValue',email,tweetId);
    }
    LikeNumber(tweetId : number):Observable<number>{
        return this.apiService.get('GetLikeNumber/'+tweetId);
    }
    DisLikeNumber(tweetId : number):Observable<number>{
        return this.apiService.get('GetDisLikeNumber/'+tweetId);
    }
 
}
