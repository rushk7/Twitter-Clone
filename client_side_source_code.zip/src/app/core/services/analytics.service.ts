import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {

    constructor(private apiService : ApiService){

    }
    GetAnalyticsToday():Observable<any>{
        return this.apiService.get('Analytics');
    }
 
}
