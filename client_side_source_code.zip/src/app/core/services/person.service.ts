import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
import {Person} from '../models/person.model';
@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private apiService : ApiService){

  }
  UnFollow(person : Person,email : string) : Observable<any>{
    return this.apiService.post1('UnFollow',person,email);
  }
  Follow(person:Person,email : string) : Observable<any>{
    return this.apiService.post1('Follow',person,email);
  }
  GetFollowers(email : string) : Observable<Person[]> {
    return this.apiService.get1('GetFollowers/',email);
  }
  GetFollowing(email : string) : Observable<Person[]>{
    return this.apiService.get1('GetFollowing/',email);
  }
  SearchPeople(query:string,email : string) : Observable<any>{
    return this.apiService.get2('SearchPeople/',query,email);
  }
  GetPerson(email:string):Observable<Person>{
    return this.apiService.get1('GetPerson',email);
  }
  DoIFollow(email:string,email1:string):Observable<Boolean>{
    return this.apiService.get5('DoIFollow',email,email1);
  }
 
}
