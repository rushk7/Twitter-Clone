import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
import {Tweet} from '../models/tweet.model';
@Injectable({
  providedIn: 'root'
})
export class TweetService {
    constructor(private apiService : ApiService) { }
    AddTweet(tweet : Tweet) : Observable<any> {
        return this.apiService.post('AddTweet/',tweet);
    }
    EditTweet(tweet : Tweet) : Observable<any>{
        return this.apiService.put('EditTweet',tweet);
    }
    DeleteTweet(id : number) : Observable<any>{
        return this.apiService.delete('DeleteTweet/'+id);
    }
    GetTweetsForUser(email : string) : Observable<Tweet[]> {
        return this.apiService.get1('GetTweetsForUser',email);
    }
    SearchTweetsForUser(query : string) : Observable<Tweet[]>{
        return this.apiService.get4('SearchTweets',query);
    }
    


 
}
