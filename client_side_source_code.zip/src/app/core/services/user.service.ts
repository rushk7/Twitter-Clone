import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
@Injectable({
  providedIn: 'root'
})
export class UserService {
    constructor(private apiService : ApiService) { }
    AddUser(user : User) : Observable<any> {
        return this.apiService.post('AddUser/',user);
    }
    GetUser(email : string) : Observable<User> {
        return this.apiService.get1('GetUser',email);
    }
    UserExists(email:string) : Observable<any> {
        return this.apiService.get1('UserExists',email);
    }
 
}
