import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import {User} from '../models/user.model';
import { UserCredential } from '../models/usercredential.model';
@Injectable({
  providedIn: 'root'
})
export class UserCredentialService {
    constructor(private apiService : ApiService) { }
    GetUserCrdential(email : string):Observable<UserCredential>{
        return this.apiService.get1('GetUserCredential/',email);
    }
    AddUserCredential(usercredential : UserCredential):Observable<any> {
        return this.apiService.post('AddUserCredential',usercredential);
    }
    Authenticate(usercredential : UserCredential) : Observable<UserCredential>{
        return this.apiService.post('Authenticate/',usercredential);
    }
 
}
