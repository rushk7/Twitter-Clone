import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import {ApiService} from './services/api.service';

import {JwtService} from './services/jwt.service';

import {UserService} from './services/user.service';
import { HttpClientModule } from '@angular/common/http'; import { HttpModule } from '@angular/http';
import { from } from 'rxjs';

import{UserCredentialService} from './services/usercredential.service';
import { TweetService } from './services/tweet.service';
import { PersonService } from './services/person.service';
import { AnalyticsService } from './services/analytics.service';
@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    HttpClientModule
  ],
  providers: [
  
    ApiService,
    JwtService,
    TweetService,
    UserCredentialService,
    UserService,
    PersonService,
    AnalyticsService
    
  ],
  declarations: []
})
export class CoreModule { }
