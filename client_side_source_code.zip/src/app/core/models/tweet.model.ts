export interface Tweet{
    id?: number,
    content?: string,
    CreatedAt ?: Date,
    ModifiedAt?: Date,
    email?: string,
}