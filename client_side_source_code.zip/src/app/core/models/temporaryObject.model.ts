import {Person} from '../models/person.model';

export interface TemporaryObject{
    person : Person;
    following:Boolean;
  }