export interface Person{
    email?: string,
    FirstName ?: string,
    LastName ?: string,
    ImageUrl?: string
}