export interface Analytics {
    TrendingHashTag?: string,
    TotalTweetsToday?: number,
    MostTweetPerson?:string,
    MostLikedTweet?: string,
}