export interface User {
    id? : number,
    FirstName? : string,
    LastName? : string,
    email?: string,
    password?: string,
    ImageUrl?: string,
    CreatedAt?: Date,
    ContactNo ?: Number,
    Country? : string,
}