export interface UserCredential {
    email?: string,
    password?: string
}