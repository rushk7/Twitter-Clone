import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , Validators } from '@angular/forms';
import { UserCredential } from 'src/app/core/models/usercredential.model';
import { Router } from '@angular/router';
import { UserCredentialService } from 'src/app/core/services/usercredential.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm : FormGroup;
  userCredential : UserCredential = {email : '',password : ''};
  navigate : Boolean;
  invalidForm : Boolean;
  
  constructor(private fb : FormBuilder,private router : Router,private usercredential : UserCredentialService) {
      this.loginForm = fb.group({
        email : ['',Validators.required],
        password : ['',Validators.required]
      });
      this.invalidForm = false;
   }

  ngOnInit() {
  }

  submit(){
    this.userCredential.email = this.loginForm.get('email').value;
    this.userCredential.password = this.loginForm.get('password').value;
    console.log(this.loginForm);
    console.log(this.userCredential);
    
    this.usercredential.Authenticate(this.userCredential)
    .subscribe(data => {
      if(data == null){
        console.log('this happened');
        this.invalidForm = true;
      }
      else {
        
        localStorage.setItem('currentuser',this.userCredential.email);
        this.router.navigate(['dashboard']);
      }
    });
   
      
  }

}
